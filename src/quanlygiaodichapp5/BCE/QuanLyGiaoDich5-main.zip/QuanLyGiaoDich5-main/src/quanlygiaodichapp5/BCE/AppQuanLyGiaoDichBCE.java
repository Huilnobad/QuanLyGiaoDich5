package quanlygiaodichapp5.BCE;

public class AppQuanLyGiaoDichBCE {
    public static void main(String[] args) {
        MenuUI menu = new MenuUI();
        menu.getChoice();
    }
}
